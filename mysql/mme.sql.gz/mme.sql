-- Adminer 4.2.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `img` varchar(255) NOT NULL,
  `shop_name` varchar(255) NOT NULL,
  `webpage` varchar(255) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `room_id` (`room_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `article_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`),
  CONSTRAINT `article_ibfk_4` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `category` (`id`, `name`, `updated_at`, `created_at`) VALUES
(4,	'Stühle',	'2015-12-16 23:22:29',	'2015-12-16 23:22:29'),
(5,	'Tische',	'2015-12-16 23:22:38',	'2015-12-16 23:22:38'),
(6,	'Schränke',	'2015-12-16 23:22:50',	'2015-12-16 23:22:50');

DROP TABLE IF EXISTS `client`;
CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `client` (`id`, `name`, `lastname`, `email`, `password`, `updated_at`, `created_at`) VALUES
(1,	'Robert',	'Dziuba',	'robert@robert.de',	'e10adc3949ba59abbe56e057f20f883e',	'2015-12-14 20:49:41',	'0000-00-00 00:00:00'),
(6,	'Inga',	'Schwarze',	'inga@schwarze.de',	'e10adc3949ba59abbe56e057f20f883e',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00');

DROP TABLE IF EXISTS `department`;
CREATE TABLE `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `department` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1,	'Wohnzimmer',	'2015-12-17 21:21:00',	'2015-12-17 21:21:00'),
(2,	'Küche',	'2015-12-17 21:20:53',	'2015-12-17 21:20:53'),
(15,	'Bad',	'2015-12-17 21:20:47',	'2015-12-17 21:20:47'),
(16,	'Schlafzimmer',	'2015-12-17 21:20:42',	'2015-12-17 21:20:42'),
(19,	'Flur',	'2015-12-17 21:20:36',	'2015-12-17 21:20:36'),
(23,	'Keller',	'2015-12-17 21:20:31',	'2015-12-17 21:20:31'),
(24,	'Garten',	'2015-12-17 21:20:18',	'2015-12-17 21:20:18'),
(25,	'Esszimmer',	'2015-12-22 21:55:30',	'2015-12-22 21:55:30');

DROP TABLE IF EXISTS `imagesRoom`;
CREATE TABLE `imagesRoom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `room_id_fk` (`room_id`),
  CONSTRAINT `room_id_fk` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `imagesRoom` (`id`, `room_id`, `image`, `thumbnail`, `created_at`, `updated_at`) VALUES
(22,	48,	'cff568e52db8435cf895686acb2d31ff6c0611281450823671',	'598.02538787024x400_758238b8f3aaf38ae5b52490ad7d41465c8d90461450823671',	'2015-12-22 22:34:31',	'2015-12-22 22:34:31'),
(23,	49,	'6e835226fc658a1597a960451d1d1f0165e071c61450823730',	'400x400_b9fd9495a5433ea5b7c25967ccb9c25af4178d2d1450823730',	'2015-12-22 22:35:30',	'2015-12-22 22:35:30'),
(24,	50,	'7e72df743112166f48ce8a5910958e30ac41741e1450823801',	'298.18956336528x400_a77add40a85b18367f7c593f0cf56d17671893a51450823801',	'2015-12-22 22:36:41',	'2015-12-22 22:36:41'),
(25,	51,	'80467fbe05494506d2197541a305b3baff808ba51450823845',	'435.71428571429x400_1c5c5153c7eb6bd5a56660f8d9030dccd5dc3d391450823845',	'2015-12-22 22:37:25',	'2015-12-22 22:37:25'),
(26,	52,	'de911ca26c9b410ec125b07807b7a0efc499bade1450823899',	'600x339.62264150943_c6185146bee1df4057962907327c34877f515bee1450823899',	'2015-12-22 22:38:19',	'2015-12-22 22:38:19'),
(27,	53,	'e78aa1a67f94694062a961c9c40c9446164fd2b51450824043',	'320x400_aba23abb62ba6873ae6a8b5014dff77a204bee7b1450824043',	'2015-12-22 22:40:43',	'2015-12-22 22:40:43'),
(28,	54,	'6d2cf84990ce973de39b074f31272378a46c20701450824086',	'520x350_75999a8e4136e817ab1640e6d32ea73c0c28cbe51450824086',	'2015-12-22 22:41:26',	'2015-12-22 22:41:26'),
(29,	55,	'd5e4dd28bb323a0fa8d2323f073a6001fd8aa70b1450824131',	'329.41176470588x400_82d331158098946cc817972ea2ce1d61415d561a1450824131',	'2015-12-22 22:42:11',	'2015-12-22 22:42:11'),
(30,	56,	'59110c3bc4351456aa60ef83da92fb87bc0c52ef1450824167',	'600x379.24528301887_1efa6904c707ef58c619e07fb7b295624c44eb321450824167',	'2015-12-22 22:42:47',	'2015-12-22 22:42:47');

DROP TABLE IF EXISTS `room`;
CREATE TABLE `room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `department_id` (`department_id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `room_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `department` (`id`),
  CONSTRAINT `room_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `client` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `room` (`id`, `department_id`, `client_id`, `name`, `title`, `description`, `updated_at`, `created_at`) VALUES
(27,	2,	6,	'tolle Küche',	'meine schöne Küche',	'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.',	'2015-12-18 00:31:12',	'2015-12-18 00:31:12'),
(29,	1,	1,	'dasdsadas',	'asdasdasd',	'adasdasdasd',	'2015-12-18 23:19:57',	'2015-12-18 23:19:57'),
(30,	1,	1,	'wadaasdas',	'adaadads',	'asdasdadasd',	'2015-12-18 23:22:35',	'2015-12-18 23:22:35'),
(31,	2,	6,	'sdfhssdsdgdgsdgsdfg',	'dfgdgdg',	'dfgdfgdfgdfg',	'2015-12-18 23:24:45',	'2015-12-18 23:24:45'),
(32,	2,	6,	'sdfhssdsdgdgsdgsdfg',	'dfgdgdg',	'dfgdfgdfgdfg',	'2015-12-18 23:26:52',	'2015-12-18 23:26:52'),
(33,	2,	6,	'sdfhssdsdgdgsdgsdfg',	'dfgdgdg',	'dfgdfgdfgdfg',	'2015-12-18 23:27:27',	'2015-12-18 23:27:27'),
(34,	2,	6,	'sdfhssdsdgdgsdgsdfg',	'dfgdgdg',	'dfgdfgdfgdfg',	'2015-12-18 23:27:50',	'2015-12-18 23:27:50'),
(48,	1,	6,	'Robust & Gemütlich',	'Rustikales Wohnen im traditionellen Design',	'Für ein gemütliches und wohnliches Zuhause: Mit diesem Stil können Sie garantiert nichts falsch machen. Sorgen Sie für ein schönes Ambiente in Ihrer Wohnung und lassen Sie Ihr Zuhause in einem neuen Look erstrahlen.',	'2015-12-22 22:34:31',	'2015-12-22 22:34:31'),
(49,	25,	1,	'Für Lebenskünstler',	'Bringen Sie mehr Farbe in Ihr Esszimmer!',	'Für ein gemütliches und wohnliches Zuhause: Mit diesem Stil können Sie garantiert nichts falsch machen. Sorgen Sie für ein schönes Ambiente in Ihrer Wohnung und lassen Sie Ihr Zuhause in einem neuen Look erstrahlen.',	'2015-12-22 22:35:30',	'2015-12-22 22:35:30'),
(50,	16,	1,	'Für Detailverliebte',	'Gut verstaut: Hier ist Platz für all Ihre Lieblingsstücke',	'Für ein gemütliches und wohnliches Zuhause: Mit diesem Stil können Sie garantiert nichts falsch machen. Sorgen Sie für ein schönes Ambiente in Ihrer Wohnung und lassen Sie Ihr Zuhause in einem neuen Look erstrahlen.',	'2015-12-22 22:36:41',	'2015-12-22 22:36:41'),
(51,	1,	6,	'Zarte Töne',	'Softe Farben für Ihr Zuhause',	'Für ein gemütliches und wohnliches Zuhause: Mit diesem Stil können Sie garantiert nichts falsch machen. Sorgen Sie für ein schönes Ambiente in Ihrer Wohnung und lassen Sie Ihr Zuhause in einem neuen Look erstrahlen.',	'2015-12-22 22:37:25',	'2015-12-22 22:37:25'),
(52,	1,	1,	'All White',	'Wohnliche Leichtigkeit: Weiß bringt Ihnen den Frische-Kick ins Wohnzimmer!',	'Für ein gemütliches und wohnliches Zuhause: Mit diesem Stil können Sie garantiert nichts falsch machen. Sorgen Sie für ein schönes Ambiente in Ihrer Wohnung und lassen Sie Ihr Zuhause in einem neuen Look erstrahlen.',	'2015-12-22 22:38:19',	'2015-12-22 22:38:19'),
(53,	2,	1,	'Pretty in Pastel',	'Fröhlichkeit kommt jetzt in Porzellan daher!',	'Für ein gemütliches und wohnliches Zuhause: Mit diesem Stil können Sie garantiert nichts falsch machen. Sorgen Sie für ein schönes Ambiente in Ihrer Wohnung und lassen Sie Ihr Zuhause in einem neuen Look erstrahlen.\r\n',	'2015-12-22 22:40:43',	'2015-12-22 22:40:43'),
(54,	2,	6,	'Allerlei für die Küche',	'Holen Sie sich den Garten in die Küche!',	'Für ein gemütliches und wohnliches Zuhause: Mit diesem Stil können Sie garantiert nichts falsch machen. Sorgen Sie für ein schönes Ambiente in Ihrer Wohnung und lassen Sie Ihr Zuhause in einem neuen Look erstrahlen.\r\n ',	'2015-12-22 22:41:26',	'2015-12-22 22:41:26'),
(55,	16,	1,	'Schöne Träume',	'Zum Einschlafen schön: Schlafgelegenheiten in ihrer gemütlichsten Form',	'Für ein gemütliches und wohnliches Zuhause: Mit diesem Stil können Sie garantiert nichts falsch machen. Sorgen Sie für ein schönes Ambiente in Ihrer Wohnung und lassen Sie Ihr Zuhause in einem neuen Look erstrahlen.',	'2015-12-22 22:42:11',	'2015-12-22 22:42:11'),
(56,	1,	1,	'Akzente setzen',	' Gegensätze ziehen sich an: Sezten Sie Akzente in Ihrem Wohnzimmer!',	'Für ein gemütliches und wohnliches Zuhause: Mit diesem Stil können Sie garantiert nichts falsch machen. Sorgen Sie für ein schönes Ambiente in Ihrer Wohnung und lassen Sie Ihr Zuhause in einem neuen Look erstrahlen.',	'2015-12-22 22:42:47',	'2015-12-22 22:42:47');

-- 2015-12-23 20:53:14
